package com.lowdragmc.lowdraglib2.editor.ui.sceneeditor.sceneobject.utils;

import com.lowdragmc.lowdraglib2.editor.ui.sceneeditor.sceneobject.ISceneRendering;
import com.lowdragmc.lowdraglib2.editor.ui.sceneeditor.sceneobject.SceneObject;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.block.BlockAndTintGetter;
import net.minecraft.client.renderer.block.BlockQuadOutput;
import net.minecraft.client.renderer.block.ModelBlockRenderer;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

public class BlockModelObject extends SceneObject implements ISceneRendering {
    public BlockState blockState = Blocks.STONE.defaultBlockState();

    public BlockModelObject() {
    }

    @Override
    @OnlyIn(Dist.CLIENT)
    public void drawInternal(PoseStack poseStack, MultiBufferSource bufferSource, float partialTicks) {
        var minecraft = Minecraft.getInstance();
        var renderer = new ModelBlockRenderer(true, true, minecraft.getBlockColors());
        var model = minecraft.getModelManager().getBlockStateModelSet().get(blockState);
        poseStack.translate(-0.5, -0.5, -0.5);
        BlockQuadOutput output = (x, y, z, quad, instance) -> {
            poseStack.pushPose();
            poseStack.translate(x, y, z);
            VertexConsumer buffer = bufferSource.getBuffer(renderTypeFor(quad.materialInfo().layer()));
            buffer.putBakedQuad(poseStack.last(), quad, instance);
            poseStack.popPose();
        };
        renderer.tesselateBlock(output, 0, 0, 0, BlockAndTintGetter.EMPTY, BlockPos.ZERO, blockState, model,
                blockState.getSeed(BlockPos.ZERO));
    }

    private static RenderType renderTypeFor(ChunkSectionLayer layer) {
        return switch (layer) {
            case SOLID -> RenderTypes.solidMovingBlock();
            case CUTOUT -> RenderTypes.cutoutMovingBlock();
            case TRANSLUCENT -> RenderTypes.translucentMovingBlock();
        };
    }
}
